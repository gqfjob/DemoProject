/* globals $ */
'use strict';

angular.module('jhipsterApp')
    .directive('jhipsterAppPager', function() {
        return {
            templateUrl: 'scripts/components/form/pager.html'
        };
    });
