/* globals $ */
'use strict';

angular.module('jhipsterApp')
    .directive('jhipsterAppPagination', function() {
        return {
            templateUrl: 'scripts/components/form/pagination.html'
        };
    });
