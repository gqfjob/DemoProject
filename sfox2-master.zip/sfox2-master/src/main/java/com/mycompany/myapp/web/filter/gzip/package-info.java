/**
 * GZipping servlet filter.
 */
package com.mycompany.myapp.web.filter.gzip;
