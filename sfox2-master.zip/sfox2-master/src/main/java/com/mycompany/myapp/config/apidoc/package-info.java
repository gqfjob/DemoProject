/**
 * Swagger api specific code.
 */
package com.mycompany.myapp.config.apidoc;