
HeartBeat
Version: 0.3
Date:     2015-04-01


#Run environment
> JRE 1.7 +
> Mysql 5.5 +


1.How to use

    1).Copy 'HeartBeat.war' to Servlet-Container-Server(Tomcat,Jetty...)
    2).Create Mysql database 'heart_beat' and run sql files: 'sql/HeartBeat.ddl';'sql/quartz_mysql_innodb.sql'
    3).Change 'HeartBeat.properties' configuration as below:
         'jdbc.url' = <your database jdbc url>
         'jdbc.username' = <your database username>
         'jdbc.password' = <your database password>
         'application.host' = <your HeartBeat application host>
        After configuration finished,  add 'HeartBeat.properties' to the Servlet-Container-Server(Tomcat,Jetty...) classpath.
     4).Startup Servlet-Container-Server(Tomcat,Jetty...) and visit it use browser


2.Change Log

    1).Add monitoring reminder log overview
    2).Fix delete instance 500 issue
    3).Update instance overview page style
    4).Refactor startup monitoring job; pause monitoring job; resume monitoring job
    5).Instance add RequestMethod: GET or POST when send monitoring request


3.Online test
    http://andaily.com/hb/


4.Project Home
    http://git.oschina.net/mkk/HeartBeat


5.License
    Apache License
    Version 2.0, January 2004
    http://www.apache.org/licenses/
