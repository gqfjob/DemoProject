
HeartBeat
Version: 0.4
Date:     2015-05-01


#Run environment
> JRE 1.7 +
> Mysql 5.5 +

#Project Encoding: UTF-8

1.How to use

    1).Copy 'HeartBeat.war' to Servlet-Container-Server(Tomcat,Jetty...)
    2).Create Mysql database 'heart_beat' and run sql files: 'sql/HeartBeat.ddl';'sql/quartz_mysql_innodb.sql'
    3).Change 'HeartBeat.properties' configuration as below:
         'jdbc.url' = <your database jdbc url>
         'jdbc.username' = <your database username>
         'jdbc.password' = <your database password>
         'application.host' = <your HeartBeat application host>

        (If want to custom you sever SMTP Email address, please config 'host.name','mail.smtp.port','mail.username',
        'mail.password','default.mail.address','mail.smtp.auth','mail.send.use.thread'. otherwise, do not change )
        After configuration finished,  add 'HeartBeat.properties' to the Servlet-Container-Server(Tomcat,Jetty...) classpath.
     4).Startup Servlet-Container-Server(Tomcat,Jetty...) and visit it use browser


2.Change Log

    1).Upgrade 'mysql-connector-java' jar version from 5.1.6 to 5.1.35 for fix use MYSQL 5.6 throw exception: 'OPTION SQL_SELECT_LIMIT=1'
    2).Add Security, Login-Account management, Register account
    3).Change instance default frequency from 10 to 30
    4).Monitor URL allow specify 'content type', add request parameter(s)
    5).Monitor URL support 'https'
    6).Upgrade httpclient version from 4.2.3 to 4.3.5
    7).ApplicationInstance add creator filed


3.Online test
    https://andaily.com/hb/


4.Project Home
    http://git.oschina.net/mkk/HeartBeat


5.License
    Apache License
    Version 2.0, January 2004
    http://www.apache.org/licenses/


6.How to upgrade from 0.3 to 0.4
   If you already deployed HeartBeat 0.3, then want to upgrade to 0.4, it is easy, please do it as follow steps:
   1). Stop the HeartBeat application
   2). Go to MySql database 'heart_beat', run 'sql/upgrade_0.4.sql' file
   3). Copy 0.4 version war file 'HeartBeat.war' replace 0.3 version war file
   4). Restart the HeartBeat application
   5). Default administrator username/password is: hb/heart_beat, use the account login or register a new account.
        Administrator account have all privileges, register account have fixed privileges: create/edit; start/stop instances

